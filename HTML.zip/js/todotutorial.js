$(document).ready(function(){
     $( 'pre' ).text( $( 'pre' ).html() );

});